@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"
title VALTIVA - IRIS AI - Atualizacao Dark 1.3
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\atualizar-site.ps1"
set "RESULTADO=%ERRORLEVEL%"
echo.
if not "%RESULTADO%"=="0" (
  echo [ATENCAO] A atualizacao nao foi confirmada. Leia as mensagens acima.
) else (
  echo [OK] Atualizacao finalizada. O mesmo site foi atualizado.
)
echo.
echo Pressione qualquer tecla para fechar...
pause >nul
exit /b %RESULTADO%
