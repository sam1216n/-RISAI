# Política de segurança

- **Nunca** envie chaves Gemini, tokens do GitHub, segredos Cloudflare ou arquivos `.env` ao GitHub.
- `GEMINI_API_KEY` deve permanecer no **segredo do Cloudflare Worker**, nunca no JS/HTML público.
- O `.gitignore` bloqueia `_NAO_COMPARTILHAR_CREDENCIAL_LOCAL/`, `*.local`, `.env` e outras extensões sensíveis.
- O histórico foi reconstituído com segredos **excluídos em todos os commits e tags**. Arquivos privados dos ZIPs originais não foram incluídos.
- Ao instalar uma versão antiga, o PowerShell solicita a chave ocultamente caso o arquivo privado não exista.
- **Troque a chave que foi compartilhada anteriormente em conversas e pacotes locais.** Apagar o arquivo do repositório não revoga credenciais existentes.
- Este repositório **não** contém workflow que faça deploy automático em Cloudflare. Publicar código no GitHub não atualiza sua API nem seu site.
- Antes de tornar o repositório público, revise permissões, conteúdo e políticas do fornecedor da API.
