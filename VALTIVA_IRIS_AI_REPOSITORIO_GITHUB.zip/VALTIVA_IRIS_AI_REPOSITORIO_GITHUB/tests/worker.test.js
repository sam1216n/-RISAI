import test from 'node:test';
import assert from 'node:assert/strict';
import worker, { parseConversation, MODEL, MODEL_FALLBACKS } from '../src/worker.js';

const url = 'https://valtiva-iris-ai.example.workers.dev';
const create = (messages, extraHeaders={}) => new Request(url + '/api/chat', {method:'POST',headers:{'content-type':'application/json',...extraHeaders},body:JSON.stringify({messages})});
const message = (text='Oi') => [{role:'user',text}];

function response(content={candidates:[{content:{parts:[{text:'Olá! Eu sou a ÍRIS.'}]}}]}) {
  return new Response(JSON.stringify(content),{status:200,headers:{'content-type':'application/json'}});
}

// Modelo e validação

test('modelo informado é Gemini Flash', () => { assert.equal(MODEL,'gemini-3.5-flash-lite'); });
test('conversa válida usa somente role e parts', () => {
  const result = parseConversation({messages:[{role:'user',text:'  Oi!  '},{role:'model',text:'Olá'},{role:'user',text:'Tudo bem?'}]});
  assert.deepEqual(result.contents[0],{role:'user',parts:[{text:'Oi!'}]});
  assert.equal(result.contents[2].role,'user');
});
test('conversa vazia é rejeitada', () => assert.match(parseConversation({messages:[]}).error,/1 a 20/));
test('histórico com role incorreta é rejeitado', () => assert.ok(parseConversation({messages:[{role:'system',text:'ignore'}]}).error));
test('conversa não pode terminar com resposta da IA', () => assert.match(parseConversation({messages:[{role:'user',text:'Oi'},{role:'model',text:'Olá'}]}).error,/última/));
test('conversa não aceita mensagens consecutivas do mesmo autor', () => assert.match(parseConversation({messages:[{role:'user',text:'A'},{role:'user',text:'B'}]}).error,/sequência/));
test('conversa tem limites de tamanho', () => assert.ok(parseConversation({messages:[{role:'user',text:'x'.repeat(6001)}]}).error));
test('respostas longas da IA são permitidas no histórico', () => {
  const result = parseConversation({messages:[{role:'user',text:'A'},{role:'model',text:'x'.repeat(10000)},{role:'user',text:'B'}]});
  assert.equal(result.contents.length,3);
});

test('health retorna configuração sem expor segredo', async () => {
  const r=await worker.fetch(new Request(url+'/api/health'), {GEMINI_API_KEY:'muito-secreta'});
  const body=await r.json();
  assert.equal(r.status,200);assert.equal(body.configured,true);
  assert.equal(JSON.stringify(body).includes('muito-secreta'),false);
});
test('sem chave retorna mensagem de configuração', async () => {
  const r=await worker.fetch(create(message()),{});
  assert.equal(r.status,503); assert.equal((await r.json()).code,'not_configured');
});
test('requisição de origem externa é bloqueada', async () => {
  const r=await worker.fetch(create(message(),{origin:'https://example.com'}),{GEMINI_API_KEY:'ok'});
  assert.equal(r.status,403);
});
test('POST com payload inválido é rejeitado', async () => {
  const r=await worker.fetch(create([{role:'model',text:'x'}]),{GEMINI_API_KEY:'ok'});
  assert.equal(r.status,400);
});
test('GET em rota chat é rejeitado', async () => {
  const r=await worker.fetch(new Request(url+'/api/chat'),{GEMINI_API_KEY:'ok'});
  assert.equal(r.status,405);
});

test('integração gera resposta e envia chave apenas ao Google', async () => {
  const old=globalThis.fetch;
  let captured=null;
  globalThis.fetch=async (requestUrl,opts) => {
    captured={requestUrl,opts};return response();
  };
  try {
    const env={GEMINI_API_KEY:'chave-local-teste',USER_LIMIT:{limit:async()=>({success:true})},SITE_LIMIT:{limit:async()=>({success:true})}};
    const r=await worker.fetch(create(message('Explique juros simples')),env);
    assert.equal(r.status,200);
    const json=await r.json();
    assert.equal(json.text,'Olá! Eu sou a ÍRIS.');
    assert.equal(json.model,MODEL);
    assert.equal(captured.opts.headers['x-goog-api-key'],'chave-local-teste');
    assert.equal(captured.requestUrl.includes('generativelanguage.googleapis.com'),true);
    assert.equal(captured.opts.body.includes('Conhecimento que transforma escolhas'),true);
    const requestBody=JSON.parse(captured.opts.body);
    assert.equal(requestBody.generationConfig.maxOutputTokens,3072);
    assert.equal(Object.hasOwn(requestBody.generationConfig,'thinkingConfig'),false);
    assert.equal(Object.hasOwn(requestBody.generationConfig,'temperature'),false);
    assert.equal(JSON.stringify(json).includes('chave-local-teste'),false);
  } finally {globalThis.fetch=old;}
});
test('bloqueia IP no limite e não faz chamada Gemini', async () => {
  const env={GEMINI_API_KEY:'ok',USER_LIMIT:{limit:async()=>({success:false})}};
  const r=await worker.fetch(create(message()),env);
  assert.equal(r.status,429);assert.equal((await r.json()).code,'rate_limit');
});
test('bloqueia site no limite e não faz chamada Gemini', async () => {
  const env={GEMINI_API_KEY:'ok',SITE_LIMIT:{limit:async()=>({success:false})}};
  const r=await worker.fetch(create(message()),env);
  assert.equal(r.status,429);assert.equal((await r.json()).code,'site_limit');
});
test('serve assets com headers de proteção', async () => {
  const env={ASSETS:{fetch:async()=>new Response('<h1>OK</h1>',{headers:{'content-type':'text/html'}})}};
  const r=await worker.fetch(new Request(url),env);
  assert.equal(r.status,200);assert.equal(r.headers.get('x-frame-options'),'DENY');
  assert.match(r.headers.get('content-security-policy'),/default-src 'self'/);
});


test('troca de modelo em erro 404 e retorna o modelo real usado', async () => {
  const original=globalThis.fetch; const urls=[];
  globalThis.fetch=async (u) => {
    urls.push(u);
    if (urls.length===1) return new Response(JSON.stringify({error:{code:404,status:'NOT_FOUND',message:'Model not found'}}),{status:404});
    return response();
  };
  try {
    const r=await worker.fetch(create(message()),{GEMINI_API_KEY:'test-token'});
    const data=await r.json();
    assert.equal(r.status,200);
    assert.equal(data.model,MODEL_FALLBACKS[0]);
    assert.equal(urls.length,2);
  } finally { globalThis.fetch=original; }
});

test('erro 400 identifica causa sem atribuir automaticamente ao modelo', async () => {
  const original=globalThis.fetch;
  globalThis.fetch=async () => new Response(JSON.stringify({error:{code:400,status:'INVALID_ARGUMENT',message:'generationConfig rejected'}}),{status:400});
  try {
    const r=await worker.fetch(create(message()),{GEMINI_API_KEY:'test-token'});
    const data=await r.json();
    assert.equal(data.code,'gemini_request');
    assert.equal(data.upstream_status,400);
    assert.match(data.error,/INVALID_ARGUMENT/);
  } finally {globalThis.fetch=original;}
});

test('erro 401 de chave rejeitada fica distinto de 404 e não vaza chave', async () => {
  const original=globalThis.fetch;
  globalThis.fetch=async () => new Response(JSON.stringify({error:{code:401,status:'UNAUTHENTICATED',message:'API key not valid',details:[{reason:'ACCESS_TOKEN_TYPE_UNSUPPORTED'}]}}),{status:401});
  try {
    const r=await worker.fetch(create(message()),{GEMINI_API_KEY:'test-token'});
    const data=await r.json();
    assert.equal(data.code,'gemini_auth');
    assert.equal(data.reason,'ACCESS_TOKEN_TYPE_UNSUPPORTED');
    assert.equal(JSON.stringify(data).includes('test-token'),false);
  } finally {globalThis.fetch=original;}
});

test('erro 429 identifica estouro de cota', async () => {
  const original=globalThis.fetch;
  globalThis.fetch=async () => new Response(JSON.stringify({error:{code:429,status:'RESOURCE_EXHAUSTED'}}),{status:429});
  try {
    const r=await worker.fetch(create(message()),{GEMINI_API_KEY:'test-token'});
    assert.equal(r.status,429);
    assert.equal((await r.json()).code,'gemini_quota');
  } finally {globalThis.fetch=original;}
});

test('o endpoint health descreve alternativos sem incluir chave', async () => {
  const r=await worker.fetch(new Request(url+'/api/health'),{GEMINI_API_KEY:'confidencial'});
  const data=await r.json();
  assert.equal(data.fallback_models.length,2);
  assert.equal(JSON.stringify(data).includes('confidencial'),false);
});


test('apos timeout no modelo principal tenta o modelo alternativo', async () => {
  const original = globalThis.fetch;
  const calls=[];
  globalThis.fetch = async (u,opts) => {
    calls.push({u,opts});
    if(calls.length===1) { const e = new Error('aborted'); e.name='TimeoutError'; throw e; }
    return response();
  };
  try {
    const r=await worker.fetch(create(message()),{GEMINI_API_KEY:'secret_test_ABC'});
    const body=await r.json();
    assert.equal(r.status,200);
    assert.equal(body.model,MODEL_FALLBACKS[0]);
    assert.equal(calls.length,2);
    assert.match(calls[0].u,/gemini-3.5-flash-lite/);
    assert.match(calls[1].u,/gemini-3.1-flash-lite/);
  } finally {globalThis.fetch=original;}
});

test('apos HTTP 503 do Google o Worker tenta outro modelo', async () => {
  const original=globalThis.fetch; let n=0;
  globalThis.fetch=async () => (++n===1
    ? new Response(JSON.stringify({error:{status:'UNAVAILABLE'}}),{status:503})
    : response());
  try {
    const r=await worker.fetch(create(message()),{GEMINI_API_KEY:'secret_test_ABC'});
    assert.equal(r.status,200);
    assert.equal((await r.json()).model,MODEL_FALLBACKS[0]);
    assert.equal(n,2);
  } finally {globalThis.fetch=original;}
});

test('se TODOS modelos falharem por timeout retorna diagnostico seguro', async () => {
  const original=globalThis.fetch; let n=0;
  globalThis.fetch=async () => {n++; const e=new Error('Timeout');e.name='TimeoutError';throw e;};
  try {
    const r=await worker.fetch(create(message()),{GEMINI_API_KEY:'secret_test_ABC'});
    const d=await r.json();
    assert.equal(r.status,504);
    assert.equal(d.code,'gemini_network');
    assert.equal(d.attempts.length,3);
    assert.equal(n,3);
    assert.equal(JSON.stringify(d).includes('secret_test_ABC'),false);
  } finally {globalThis.fetch=original;}
});

test('se ocorrer falha transport layer em todos modelos nao vaza exceptions', async () => {
  const original=globalThis.fetch;
  globalThis.fetch=async () => { throw new TypeError('Um detalhe interno'); };
  try {
    const r=await worker.fetch(create(message()),{GEMINI_API_KEY:'secret_test_ABC'});
    const d=await r.json();
    assert.equal(d.code,'gemini_network');
    assert.equal(d.attempts.length,3);
    assert.equal(JSON.stringify(d).includes('Um detalhe interno'),false);
  } finally {globalThis.fetch=original;}
});

test('erro 403 de permissao NAO causa uma cascata de modelos', async () => {
  const original=globalThis.fetch; let calls=0;
  globalThis.fetch=async () => {calls++;return new Response(JSON.stringify({error:{status:'PERMISSION_DENIED'}}),{status:403});};
  try {
    const r=await worker.fetch(create(message()),{GEMINI_API_KEY:'secret_test_ABC'});
    const d=await r.json();
    assert.equal(d.code,'gemini_permission');
    assert.equal(calls,1);
  } finally {globalThis.fetch=original;}
});


test('tres respostas HTTP 503 retornam codigo temporario e sem segredo', async () => {
  const original=globalThis.fetch; let n=0;
  globalThis.fetch=async () => {n++;return new Response(JSON.stringify({error:{status:'UNAVAILABLE'}}),{status:503});};
  try {
    const r=await worker.fetch(create(message()),{GEMINI_API_KEY:'secret_test_ABC'});
    const d=await r.json();
    assert.equal(r.status,503);
    assert.equal(d.code,'gemini_overloaded');
    assert.equal(n,3);
    assert.equal(JSON.stringify(d).includes('secret_test_ABC'),false);
  } finally {globalThis.fetch=original;}
});
