# ÍRIS AI — VALTIVA | atualização visual (sem editar/apagar secrets)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$project = Split-Path -Parent $PSScriptRoot
$site = 'https://valtiva-iris-ai.aura-samuel.workers.dev'

function Banner($label) {
    Write-Host ''
    Write-Host '===============================================================' -ForegroundColor DarkCyan
    Write-Host "  $label" -ForegroundColor Cyan
    Write-Host '===============================================================' -ForegroundColor DarkCyan
}
function Run-Checked($command, [string[]]$arguments) {
    & $command @arguments
    if ($LASTEXITCODE -ne 0) { throw "Falha no comando $command (codigo $LASTEXITCODE)." }
}

try {
    Set-Location $project
    Banner 'VALTIVA / IRIS AI / ATUALIZACAO DARK PREMIUM v1.3'
    Write-Host 'Este procedimento ATUALIZA o Worker existente.'
    Write-Host 'Nao cria outro site, nao apaga a chave Gemini e nao pede API key.'
    Write-Host "Destino: $site"

    Banner '1/5 — Verificando ambiente'
    $node = Get-Command 'node.exe' -ErrorAction SilentlyContinue
    $npm = Get-Command 'npm.cmd' -ErrorAction SilentlyContinue
    $npx = Get-Command 'npx.cmd' -ErrorAction SilentlyContinue
    if (-not $node -or -not $npm -or -not $npx) {
        throw 'Node.js / npm nao encontrados. Instale Node.js em https://nodejs.org e execute de novo.'
    }
    Run-Checked 'node.exe' @('--version')

    Banner '2/5 — Dependencias e testes locais'
    Run-Checked 'npm.cmd' @('install', '--no-audit', '--no-fund')
    Run-Checked 'npm.cmd' @('test')

    Banner '3/5 — Conta Cloudflare'
    & npx.cmd --no-install wrangler whoami
    if ($LASTEXITCODE -ne 0) {
        Write-Host 'Login necessario. O navegador do Cloudflare sera aberto...' -ForegroundColor Yellow
        Run-Checked 'npx.cmd' @('--no-install','wrangler','login')
    }
    Write-Host 'Use a MESMA conta Cloudflare que ja hospeda o site.' -ForegroundColor Yellow

    Banner '4/5 — Publicando novo visual no MESMO Worker'
    # Nome idêntico ao projeto original em wrangler.jsonc.
    # Deploy normal mantém secrets ja cadastrados no Worker existente.
    Run-Checked 'npx.cmd' @('--no-install','wrangler','deploy')

    Banner '5/5 — Validacao do site publicado'
    Start-Sleep -Seconds 3
    $main = Invoke-WebRequest -Uri $site -UseBasicParsing -TimeoutSec 25
    if ($main.StatusCode -ne 200 -or $main.Content -notmatch 'ÍRIS AI') {
        throw 'O novo HTML nao pôde ser confirmado no endereco publico.'
    }
    Write-Host '[OK] Site publico responde HTTP 200.' -ForegroundColor Green
    try {
        $health = Invoke-RestMethod -Uri "$site/api/health" -TimeoutSec 25
        if ($health.configured) {
            Write-Host '[OK] GEMINI_API_KEY continua configurada no servidor.' -ForegroundColor Green
        } else {
            Write-Host '[AVISO] Site publicado, mas a chave Gemini nao foi encontrada neste Worker.' -ForegroundColor Yellow
            Write-Host 'Confira se entrou na mesma conta Cloudflare do site antigo.'
        }
    } catch {
        Write-Host '[AVISO] O status da API nao pôde ser consultado agora.' -ForegroundColor Yellow
        Write-Host 'Isso nao significa que a publicação tenha falhado.'
    }
    Banner 'PUBLICACAO DO VISUAL CONCLUIDA'
    Write-Host "Site: $site" -ForegroundColor Green
    Write-Host 'Atualize a pagina com Ctrl + F5 (o historico local e preservado).'
    Write-Host 'O chatbot usa a mesma integracao Gemini configurada anteriormente.'
    exit 0
} catch {
    Write-Host ''
    Write-Host "[ERRO] $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'A versao que ja estava no Cloudflare nao foi apagada por este script.' -ForegroundColor Yellow
    exit 1
}
