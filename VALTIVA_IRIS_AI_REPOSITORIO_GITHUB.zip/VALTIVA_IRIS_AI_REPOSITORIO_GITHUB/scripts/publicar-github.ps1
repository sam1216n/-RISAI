$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$repo = 'sam1216n/VALTIVA-IRIS-AI'
function Stop-Fail([string]$message){ Write-Host "[ERRO] $message" -ForegroundColor Red; exit 1 }
function Check-Exe([string]$name,[string]$wingetId,[string[]]$candidatePaths){
  $c = Get-Command $name -ErrorAction SilentlyContinue
  if ($c) { return $c.Source }
  foreach($p in $candidatePaths){ if(Test-Path $p){ return $p } }
  $winget = Get-Command winget -ErrorAction SilentlyContinue
  if(-not $winget){ Stop-Fail "Instale $name manualmente e execute novamente. Winget nao encontrado." }
  Write-Host "Instalando $name usando o Windows Package Manager..." -ForegroundColor Cyan
  & winget install --id $wingetId --exact --source winget --accept-package-agreements --accept-source-agreements
  if($LASTEXITCODE -ne 0){ Stop-Fail "Nao foi possivel instalar $name. Instale manualmente e execute novamente." }
  $c = Get-Command $name -ErrorAction SilentlyContinue
  if($c){ return $c.Source }
  foreach($p in $candidatePaths){ if(Test-Path $p){ return $p } }
  Stop-Fail "$name instalado, mas nao encontrado nesta sessao. Feche o terminal e execute o .bat novamente."
}
try {
  Set-Location $root
  $git = Check-Exe 'git' 'Git.Git' @("$env:ProgramFiles\Git\cmd\git.exe", "${env:ProgramFiles(x86)}\Git\cmd\git.exe")
  $gh = Check-Exe 'gh' 'GitHub.cli' @("$env:ProgramFiles\GitHub CLI\gh.exe", "${env:LOCALAPPDATA}\Programs\GitHub CLI\gh.exe")
  if(-not (Test-Path '.git')){ Stop-Fail 'Pasta .git ausente. Extraia o ZIP completo com todos os arquivos ocultos.' }
  & $git fsck --full --no-reflogs
  if($LASTEXITCODE -ne 0){ Stop-Fail 'Historico Git local com problema. Extraia novamente o ZIP completo.' }
  if((& $git status --porcelain)){ Stop-Fail 'Existem alteracoes locais nao registradas. Confira git status antes de publicar.' }
  $historico = & $git log -p --all --no-ext-diff --pretty=format: 2>$null | Out-String
  if($historico -match 'AQ\.[A-Za-z0-9_-]{18,}|AIza[A-Za-z0-9_-]{24,}|ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}'){
    Stop-Fail 'Foi encontrada uma chave com formato sensivel no historico. Publicacao interrompida.'
  }
  Write-Host '[OK] Historico validado e sem padroes de tokens nos diffs.' -ForegroundColor Green
  & $gh auth status *> $null
  if($LASTEXITCODE -ne 0){
    Write-Host 'Conecte sua conta do GitHub no navegador...' -ForegroundColor Cyan
    & $gh auth login -h github.com -p https -w
    if($LASTEXITCODE -ne 0){ Stop-Fail 'Login no GitHub nao concluido.' }
  }
  $login = (& $gh api user --jq '.login').Trim()
  if($LASTEXITCODE -ne 0 -or $login -ne 'sam1216n') { Stop-Fail "Voce esta conectado como '$login'. E necessario entrar no GitHub sam1216n para criar o repositorio." }
  & $gh repo view $repo --json name --jq '.name' *> $null
  if($LASTEXITCODE -ne 0){
    Write-Host "Criando repositorio PRIVADO https://github.com/$repo ..." -ForegroundColor Cyan
    & $gh repo create $repo --private --source $root --remote origin --push
    if($LASTEXITCODE -ne 0){ Stop-Fail 'Nao foi possivel criar ou enviar o repositorio. Confira os avisos acima.' }
  } else {
    Write-Host "Repositorio ja existe: $repo" -ForegroundColor Cyan
    $remote = & $git remote get-url origin 2>$null
    if($LASTEXITCODE -ne 0){ & $git remote add origin "https://github.com/$repo.git" }
    elseif($remote -notmatch '(^https://github\.com/sam1216n/VALTIVA-IRIS-AI(?:\.git)?$|^git@github\.com:sam1216n/VALTIVA-IRIS-AI\.git$)'){
      Stop-Fail "Remote origin aponta para outro repositorio. Revise antes de publicar: $remote"
    }
    & $git push -u origin main
    if($LASTEXITCODE -ne 0){ Stop-Fail 'Push main recusado. Confira permissoes e divergencias do historico; nao use --force.' }
  }
  & $git push origin --tags
  if($LASTEXITCODE -ne 0){ Stop-Fail 'Historico principal publicado, mas as tags nao foram enviadas.' }
  Write-Host "[OK] Publicado! https://github.com/$repo" -ForegroundColor Green
  Write-Host 'O projeto Cloudflare nao sofreu nenhuma alteracao.' -ForegroundColor DarkGray
} catch {
  Stop-Fail $_.Exception.Message
}
