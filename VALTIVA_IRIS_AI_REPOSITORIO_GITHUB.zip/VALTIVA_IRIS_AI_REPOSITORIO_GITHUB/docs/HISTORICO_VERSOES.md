# Histórico de versões — ÍRIS AI / VALTIVA

> Histórico **reconstruído em 08/11/2026** a partir dos cinco ZIPs entregues durante o projeto. As tags correspondem a estados reais dos arquivos, mas seus commits não são os commits originais de desenvolvimento. Credenciais e arquivos locais foram eliminados em **todas** as versões. A exigência de arquivo de chave foi substituída por uma entrada segura opcional nos instaladores antigos. Outras diferenças técnicas foram preservadas.

## v1.0.0 — Primeira versão
- **Implementado:** interface de chat, logo institucional VALTIVA, histórico local no navegador, sugestões de prompt, chamada `/api/chat` no Cloudflare Worker, rate limiting, testes locais e deploy Windows.
- **Limitação observada posteriormente:** o backend usava apenas `gemini-3.8-flash` e não distinguia suficientemente as causas de rejeição do Google.
- **Testes desta reconstrução:** ver `docs/VALIDACAO.md`.

## v1.0.1 — Instalador com segredo automático
- **Alterado:** script PowerShell passou a automatizar mais etapas de publicação, inserção de `GEMINI_API_KEY` como segredo do Worker e checagem após o deploy.
- **Risco identificado:** pacote original distribuído localmente incluía arquivo privado de credencial. Este repositório **não** inclui a chave nem o arquivo, inclusive na tag desta versão. O instalador sanitizado permite entrada oculta caso o arquivo privado não exista.
- **Problema ainda não resolvido:** respostas do Gemini falhavam em alguns testes reais.

## v1.1.0 — Diagnóstico e modelos alternativos
- **Corrigido:** mensagens de erro do Google deixaram de tratar todo erro como modelo indisponível. Passou a diferenciar falhas 400, 401, 403 e 429 e erros 404.
- **Adicionado:** modelos alternativos em erros de modelo não encontrado; teste de chave direto no Google e checagem mais detalhada da publicação.
- **Novo erro identificado pelo usuário:** o site publicou corretamente e o segredo foi aceito pelo Cloudflare, mas o teste real retornou `upstream_timeout`. O fallback disponível não resolvia essa categoria de falha.

## v1.2.0 — Tratamento de timeout
- **Corrigido:** fallback também é tentado em falhas de rede/timeouts/indisponibilidade temporária; teste de inicialização e diagnóstico da implantação foram ajustados.
- **Alterado:** `gemini-3.5-flash-lite` virou modelo principal, após ter respondido num teste direto feito pelo instalador do usuário. Modelos alternativos permanecem disponíveis.
- **Validação:** 28 testes de servidor passaram localmente na época e novamente nesta reconstrução. A resposta real da API depende da chave e de disponibilidade do Google e não foi testada nesta reconstrução.

## v1.3.0 — Dark Premium
- **Alterado:** redesign completo para tema escuro, profundidade visual, identidade azul-marinho/menta, ajustes de interface desktop/mobile e melhores componentes do chat.
- **Adicionado:** atualizador `ATUALIZAR_SITE.bat`, mantendo a mesma URL/Worker e preservando o segredo Gemini já cadastrado.
- **Preservado:** backend e testes da v1.2.0; não há evidência de nova alteração de modelo na v1.3.0.
- **Validação:** 28 testes locais; prévias visuais em `docs/preview-desktop.png` e `docs/preview-mobile.png`.

## Após v1.3.0 — Organização do repositório
- Foram acrescentados documentos, publicação automática opcional via GitHub CLI e revisão de segurança; o código da interface e do Worker v1.3.0 foi mantido.
- O site Cloudflare **não é** atualizado pela publicação no GitHub. O deploy do site permanece independente.

## Como comparar versões

```bash
git log --oneline --decorate --graph --all
git diff v1.0.0 v1.1.0 -- src/worker.js
git diff v1.2.0 v1.3.0 -- public/styles.css
```

Para ver uma versão antiga: `git switch --detach v1.1.0`. Para retornar: `git switch main`.
