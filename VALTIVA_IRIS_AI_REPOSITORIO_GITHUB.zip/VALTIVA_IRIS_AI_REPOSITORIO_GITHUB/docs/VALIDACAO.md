# Matriz de validação

Os testes aqui registrados foram executados com Node.js 22 na reconstrução local, **sem chamadas reais à API do Google**.

| Versão | Testes automatizados locais | Resultado |
|---|---:|---|
| 1.0.0 | 17 | aprovados |
| 1.0.1 | 17 | aprovados |
| 1.1.0 | 22 | aprovados |
| 1.2.0 | 28 | aprovados |
| 1.3.0 | 28 | aprovados |

Os testes do Worker simulam respostas do Google e validam rotas, validação de payload, limites e tratamento de erros. Eles **não comprovam** que um modelo Gemini responderá com qualquer chave real, nem garantem deploy Cloudflare. O usuário relatou problemas reais de conexão que motivaram as correções documentadas.

Execute localmente: `npm test`. Para testar produção, publique com Wrangler, configure o segredo `GEMINI_API_KEY` e envie uma mensagem de teste pela interface.

## Auditoria dos commits
O histórico gerado também passa por varredura de tokens com padrão comum e por `git fsck --full`. O publicador aborta se detectar um segredo em diffs Git.
