# Registro de incidentes e bugs

Este documento separa **observação**, **hipótese**, **correção aplicada** e **estado da validação**. Não transforma erro suspeito em erro comprovado.

| ID | Versões afetadas | Ocorrência observada | Correção aplicada | Estado |
|---|---|---|---|---|
| IRIS-001 | 1.0.0–1.0.1 | UI mostrava “O modelo Gemini não está disponível para esta chave” após envio de “oi”. Isso não determinava o real erro upstream. | v1.1.0 adicionou mapeamento específico 400/401/403/404/429. | Corrigido em testes locais de erro simulado; requer validação real. |
| IRIS-002 | 1.1.0 | No log real de publicação, cloudflare e segredo OK mas `/api/chat` retornou `upstream_timeout` ao contatar Google. | v1.2.0 tenta fallback também em timeout/rede/503 e altera o modelo primário. | Corrigido nos testes automatizados de fallback; verificação real externa não disponível neste ambiente. |
| IRIS-003 | 1.0.1–1.2.0 (pacotes privados) | ZIPs de publicação locais traziam um arquivo de chave Gemini. | Excluir arquivo privado de **todos os commits/tags**; revisar `.gitignore`; pedir chave de forma oculta quando necessário. | Mitigação implementada no repositório. A credencial anteriormente compartilhada deve ser rotacionada. |
| IRIS-004 | 1.0.0–1.2.0 | Interface clara com fundo branco foi considerada visualmente sem personalidade. | v1.3.0: Dark Premium, cores institucionais, nova composição responsiva. | Alteração entregue e visualmente validada nas prévias. |
| IRIS-005 | 1.3.0 | A execução real depende de segredo ativo, cota e modelos habilitados na API Gemini. | Mensagens e health do Worker ajudam no diagnóstico; não existem testes de produção com chave no repositório. | Dependência externa / acompanhar. |

## Como registrar novos bugs

Registre data, versão, URL/ambiente, passos para reproduzir, resultado esperado, resultado observado, logs **sem credenciais**, commit da correção e resultado do teste. Nunca anexe `.env`, chaves ou cópias de `gemini_api_key.local`.
