# ÍRIS AI — VALTIVA

**ÍRIS AI** é o assistente conversacional da VALTIVA, independente do jogo educacional *Além do Saldo*. Interface em português, com tema **Dark Premium**, hospedagem no Cloudflare Workers e integração Gemini pelo servidor, sem login do usuário final.

![Interface Dark Premium da ÍRIS AI](docs/preview-desktop.png)

## Funcionalidades

- Chat de perguntas gerais com histórico local no navegador, sugestões e interface responsiva.
- Design institucional VALTIVA nas cores azul-marinho, azul-elétrico e menta.
- Endpoint de chat hospedado em Cloudflare Worker, com limites e verificações.
- Chave Gemini armazenada apenas no servidor Cloudflare como segredo.
- Atualizador Windows `.bat` que mantém a URL existente sem apagar o segredo.
- Testes do servidor com Node.js.

## Documentação

- [Histórico completo das 5 versões](docs/HISTORICO_VERSOES.md)
- [Erros encontrados, correções e status](docs/ERROS_E_STATUS.md)
- [Validação e limites dos testes](docs/VALIDACAO.md)
- [Segurança e proteção da API](SECURITY.md)

## Versões reconstruídas

| Tag | Descrição |
|---|---|
| [v1.0.0](../../tree/v1.0.0) | Base do chat |
| [v1.0.1](../../tree/v1.0.1) | Publicador com secret |
| [v1.1.0](../../tree/v1.1.0) | Diagnósticos e alternativos |
| [v1.2.0](../../tree/v1.2.0) | Fallback de timeout |
| [v1.3.0](../../tree/v1.3.0) | Dark Premium |

> As tags foram reconstruídas dos cinco ZIPs anteriores em 08/11/2026; não representam commits feitos nas datas originais. Os instaladores históricos foram sanitizados para **não exigirem chave embutida**.

## Como desenvolver

Requisitos: **Node.js >= 20**.

```bash
npm install
npm test
npx wrangler dev
```

## Atualizar site já implantado

No Windows, execute `ATUALIZAR_SITE.bat` depois de autenticar sua conta Cloudflare. O Worker configurado em `wrangler.jsonc` será atualizado, mantendo a URL e o segredo existente.

Para configurar o segredo em uma instalação nova, execute:

```bash
npx wrangler deploy
npx wrangler secret put GEMINI_API_KEY --name valtiva-iris-ai
```

Digite a chave **somente no terminal**, nunca no repositório Git. O comando Wrangler usa o projeto Cloudflare autenticado.

## Publicar este histórico em um novo repositório GitHub

No Windows, use **`PUBLICAR_GITHUB.bat`**. Ele instala/verifica Git e GitHub CLI, pede login caso necessário, cria o repositório **privado** `sam1216n/VALTIVA-IRIS-AI` (caso ainda não exista) e publica commits, tags e documentação. A publicação no GitHub é separada do deploy do site.

![Visualização móvel](docs/preview-mobile.png)

---
**VALTIVA · Conhecimento que transforma escolhas.**
