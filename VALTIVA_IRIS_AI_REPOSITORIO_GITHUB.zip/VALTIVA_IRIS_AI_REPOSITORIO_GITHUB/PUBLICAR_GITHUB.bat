@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo =======================================================
echo   VALTIVA - IRIS AI - Publicar historico no GitHub
echo =======================================================
echo Este processo nao publica o site Cloudflare.
echo E apenas o codigo-fonte e o historico Git, sem chave API.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\publicar-github.ps1"
set "EXIT_CODE=%ERRORLEVEL%"
if not "%EXIT_CODE%"=="0" (
 echo.
 echo [ERRO] Falha no processo. Leia o erro acima.
) else (
 echo.
 echo [OK] Verifique o repositório GitHub mostrado acima.
)
pause
exit /b %EXIT_CODE%
