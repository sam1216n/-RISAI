/* ÍRIS AI — VALTIVA: interface sem dependências, histórico somente no navegador. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const STORAGE = 'valtiva_iris_history_v1';
  const maxUserChars = 6000;
  const historyLimit = 18;
  const dom = {
    shell: $('shell'), sidebar: $('sidebar'), shade: $('shade'), menuToggle: $('menuToggle'),
    scroller: $('chatScroller'), welcome: $('welcome'), conversation: $('conversation'),
    form: $('chatForm'), input: $('prompt'), send: $('sendBtn'), counter: $('counter'),
    sessionName: $('sessionName'), status: $('status'), statusText: $('statusText'),
    about: $('aboutDialog'),
    newChat: $('newChat'), clearBtn: $('clearBtn')
  };
  let messages = [];
  let pending = false;
  let controller = null;
  let requestId = 0;

  const readHistory = () => {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE) || '[]');
      if (!Array.isArray(saved)) return [];
      return saved.filter(t => t && (t.role === 'user' || t.role === 'model')
        && typeof t.text === 'string' && t.text.length > 0 && t.text.length <= 30000).slice(-historyLimit);
    } catch { return []; }
  };
  const saveHistory = () => { try { localStorage.setItem(STORAGE, JSON.stringify(messages.slice(-historyLimit))); } catch {} };
  const make = (tag, className = '', content = null) => {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (content !== null) el.textContent = content;
    return el;
  };

  function inlineFormat(text, parent) {
    // Todos os conteúdos passam por textContent; nenhuma saída do modelo é tratada como HTML.
    const rx = /(\*\*([^*\n]+)\*\*|`([^`\n]+)`|\*([^*\n]+)\*|\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\))/g;
    let cursor = 0, match;
    while ((match = rx.exec(text))) {
      if (match.index > cursor) parent.append(document.createTextNode(text.slice(cursor, match.index)));
      if (match[2]) parent.append(make('strong', '', match[2]));
      else if (match[3]) parent.append(make('code', '', match[3]));
      else if (match[4]) parent.append(make('em', '', match[4]));
      else if (match[5] && match[6]) {
        const link = make('a', '', match[5]);
        link.href = match[6]; link.target = '_blank'; link.rel = 'noopener noreferrer';
        parent.append(link);
      }
      cursor = rx.lastIndex;
    }
    if (cursor < text.length) parent.append(document.createTextNode(text.slice(cursor)));
  }

  function markdownToDOM(md) {
    const root = make('div', 'answer');
    const lines = md.replace(/\r\n?/g, '\n').split('\n');
    let i = 0;
    while (i < lines.length) {
      const line = lines[i];
      if (!line.trim()) { i++; continue; }
      if (/^\s*```/.test(line)) {
        const language = line.trim().slice(3).trim().replace(/[^\w+#.-]/g, '').slice(0, 24);
        i++;
        const collected = [];
        while (i < lines.length && !/^\s*```/.test(lines[i])) collected.push(lines[i++]);
        if (i < lines.length) i++;
        const pre = make('pre'); const code = make('code', '', collected.join('\n'));
        if (language) code.dataset.language = language;
        pre.append(code); root.append(pre); continue;
      }
      const h = /^(#{1,3})\s+(.+)$/.exec(line);
      if (h) { const node = make(h[1].length === 1 ? 'h2' : 'h3'); inlineFormat(h[2], node); root.append(node); i++; continue; }
      const bullet = /^\s*([-*]|\d+\.)\s+(.+)$/.exec(line);
      if (bullet) {
        const ordered = /\d+\./.test(bullet[1]);
        const list = make(ordered ? 'ol' : 'ul');
        while (i < lines.length) {
          const b = /^\s*([-*]|\d+\.)\s+(.+)$/.exec(lines[i]);
          if (!b || /\d+\./.test(b[1]) !== ordered) break;
          const li = make('li'); inlineFormat(b[2], li); list.append(li); i++;
        }
        root.append(list); continue;
      }
      const paragraph = [];
      while (i < lines.length && lines[i].trim() && !/^(#{1,3}\s+|\s*```|\s*[-*]\s+|\s*\d+\.\s+)/.test(lines[i])) paragraph.push(lines[i++]);
      if (!paragraph.length) { i++; continue; }
      const p = make('p'); inlineFormat(paragraph.join('\n'), p);
      p.style.whiteSpace = 'pre-line'; root.append(p);
    }
    return root;
  }

  function createMessage(role, text, options = {}) {
    const row = make('article', `message ${role}`);
    const avatar = make('div', 'avatar');
    if (role === 'model') {
      const image = make('img'); image.src = '/assets/valtiva-mark.png'; image.alt = '';
      avatar.append(image);
    } else avatar.textContent = 'V';
    const content = make('div', 'message-body');
    const author = make('div', 'message-author', role === 'user' ? 'Você' : 'ÍRIS AI');
    content.append(author);
    if (options.thinking) {
      const load = make('div', 'thinking');
      for (let i = 0; i < 3; i++) load.append(make('i'));
      load.append(make('span', '', 'Pensando em uma resposta...'));
      content.append(load);
    } else {
      content.append(role === 'model' ? markdownToDOM(text) : make('div', 'answer', text));
      if (role === 'model') {
        const actions = make('div', 'answer-actions');
        const copy = make('button', 'tiny-action', '▢  Copiar resposta');
        copy.type = 'button';
        copy.addEventListener('click', async () => {
          try { await navigator.clipboard.writeText(text); copy.textContent = '✓  Copiado'; setTimeout(() => copy.textContent = '▢  Copiar resposta', 1700); }
          catch { copy.textContent = 'Não foi possível copiar'; }
        });
        actions.append(copy); content.append(actions);
      }
    }
    row.append(avatar, content); return row;
  }

  function scrollBottom() {
    requestAnimationFrame(() => { dom.scroller.scrollTop = dom.scroller.scrollHeight; });
  }
  function updateSession() {
    dom.sessionName.textContent = messages.find(t => t.role === 'user')?.text.replace(/\s+/g,' ').slice(0, 26) || 'Nova conversa';
    dom.welcome.hidden = messages.length > 0;
    dom.conversation.hidden = messages.length === 0;
  }
  function renderAll() {
    dom.conversation.replaceChildren();
    for (const m of messages) dom.conversation.append(createMessage(m.role, m.text));
    updateSession();
    if (messages.length) scrollBottom();
    else dom.scroller.scrollTop = 0;
  }
  function setMenu(open) {
    dom.shell.classList.toggle('menu-open', open);
    dom.menuToggle.setAttribute('aria-expanded', String(open));
    dom.menuToggle.setAttribute('aria-label', open ? 'Fechar menu' : 'Abrir menu');
  }
  function autoHeight() {
    dom.input.style.height = 'auto';
    dom.input.style.height = Math.min(dom.input.scrollHeight, 170) + 'px';
    const count = dom.input.value.length;
    dom.counter.hidden = count < 4500;
    dom.counter.textContent = `${count} / ${maxUserChars}`;
    dom.send.disabled = pending || count === 0 || !dom.input.value.trim();
  }
  function setPending(value) {
    pending = value; dom.send.disabled = value || !dom.input.value.trim();
    dom.input.disabled = value;
    dom.input.placeholder = value ? 'A ÍRIS está preparando sua resposta...' : 'Escreva sua pergunta para a ÍRIS...';
    dom.send.setAttribute('aria-busy', String(value));
  }
  function status(state) {
    dom.status.classList.toggle('is-offline', state === 'off');
    dom.statusText.textContent = state === 'ready' ? 'IA respondendo' : state === 'configured' ? 'API configurada' : 'Aguardando configuração';
    dom.status.title = state === 'ready' ? 'Uma resposta real foi confirmada nesta sessão' : state === 'configured' ? 'Chave encontrada; conexão ainda não validada' : 'Ainda sem chave Gemini no Cloudflare';
  }
  async function getHealth() {
    try {
      const res = await fetch('/api/health', { cache: 'no-store' });
      if (!res.ok) throw new Error('http');
      const data = await res.json(); status(data.configured ? 'configured' : 'off');
    } catch { status('off'); }
  }

  function addError(row, errMessage, userText) {
    const target = row.querySelector('.message-body');
    const alert = make('div','error-note',errMessage);
    alert.setAttribute('role', 'alert');
    const retry = make('button', 'retry', 'Tentar novamente');
    retry.type = 'button';
    retry.addEventListener('click', () => {
      if (pending) return;
      dom.input.value = userText;
      autoHeight(); dom.input.focus();
      row.remove();
      submitMessage();
    });
    alert.append(document.createElement('br'), retry); target.append(alert);
    scrollBottom();
  }

  async function submitMessage() {
    if (pending) return;
    const prompt = dom.input.value.trim();
    if (!prompt || prompt.length > maxUserChars) return;
    dom.input.value = ''; autoHeight(); setMenu(false);
    messages.push({ role: 'user', text: prompt });
    messages = messages.slice(-historyLimit);
    saveHistory();
    if (messages.length === 1) { dom.conversation.replaceChildren(); }
    updateSession();
    const row = createMessage('user', prompt);
    const typing = createMessage('model', '', {thinking:true});
    dom.conversation.append(row, typing); scrollBottom();
    setPending(true);
    controller = new AbortController();
    const myId = ++requestId;
    const timeout = setTimeout(() => controller?.abort(), 76000);
    try {
      // A última mensagem é sempre do usuário; limitar ao contexto recente.
      let context = messages.slice(-19);
      while (context.length && context[0].role !== 'user') context = context.slice(1);
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ messages: context }),
        signal: controller.signal,
        cache: 'no-store'
      });
      let payload;
      try { payload = await response.json(); } catch { payload = {}; }
      if (myId !== requestId) return;
      typing.remove();
      if (!response.ok || !payload.ok || !payload.text) throw new Error(payload.error || 'Não foi possível receber uma resposta.');
      status('ready');
      messages.push({role: 'model', text: payload.text});
      messages = messages.slice(-historyLimit);
      saveHistory();
      dom.conversation.append(createMessage('model', payload.text)); scrollBottom();
    } catch (e) {
      if (myId !== requestId) return;
      typing.remove();
      messages.pop(); // Uma mensagem falhada não entra no histórico conversacional.
      saveHistory();
      addError(row, e?.name === 'AbortError' ? 'A resposta demorou demais. Tente enviar novamente.' : (e.message || 'Erro ao conversar com a ÍRIS.'), prompt);
    } finally {
      clearTimeout(timeout);
      if (myId === requestId) { controller = null; setPending(false); autoHeight(); dom.input.focus(); }
    }
  }

  function newConversation() {
    if (controller) controller.abort();
    requestId++; controller = null; setPending(false);
    messages = []; saveHistory(); renderAll();
    dom.input.value = ''; autoHeight(); dom.input.focus(); setMenu(false);
  }
  dom.form.addEventListener('submit', (e) => { e.preventDefault(); submitMessage(); });
  dom.input.addEventListener('input', autoHeight);
  dom.input.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); submitMessage(); }
  });
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); newConversation(); }
    if (e.key === 'Escape') setMenu(false);
  });
  dom.newChat.addEventListener('click', newConversation);
  dom.clearBtn.addEventListener('click', () => {
    if (!messages.length || confirm('Iniciar uma nova conversa e limpar o histórico deste navegador?')) newConversation();
  });
  $('menuToggle').addEventListener('click', () => setMenu(!dom.shell.classList.contains('menu-open')));
  dom.shade.addEventListener('click', () => setMenu(false));
  $('aboutBtn').addEventListener('click', () => { dom.about.showModal(); setMenu(false); });
  $('closeAbout').addEventListener('click', () => dom.about.close());
  dom.about.addEventListener('click', e => { if (e.target === dom.about) dom.about.close(); });
  $('sidebarSuggestion').addEventListener('click', () => {
    dom.input.value = 'Quais são 5 maneiras criativas de usar tecnologia para aprender melhor?';
    autoHeight(); dom.input.focus(); setMenu(false);
  });
  for (const b of document.querySelectorAll('[data-prompt]')) b.addEventListener('click', () => {
    dom.input.value = b.dataset.prompt; autoHeight(); submitMessage();
  });
  messages = readHistory();
  autoHeight(); renderAll(); getHealth();
})();
